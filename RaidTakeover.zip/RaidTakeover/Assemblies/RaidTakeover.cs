using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;

namespace RaidTakeover
{
    [StaticConstructorOnStartup]
    internal static class ModInit
    {
        static ModInit()
        {
            var harmony = new Harmony("raider.takeover.grok");
            harmony.PatchAll();
            Log.Message("[RaidTakeover] Loaded - Raiders will now conquer instead of game over!");
        }
    }

    [HarmonyPatch(typeof(GameEnder), "CheckOrUpdateGameOver")]
    internal static class Patch_GameEnder_CheckOrUpdateGameOver
    {
        internal static bool Prefix()
        {
            if (Find.CurrentMap == null) return true;

            Map map = Find.CurrentMap;

            // No healthy free colonists?
            bool colonyDefeated = !map.mapPawns.FreeColonists.Any(p => !p.Downed);

            if (!colonyDefeated) return true;

            // Raiders still here (assault lord confirms raid)?
            bool raidOngoing = map.lordManager.lords.Any(lord => lord.LordJob is LordJob_AssaultColony);

            if (!raidOngoing) return true;

            // TAKEOVER!
            DoTakeover(map);

            Messages.Message("The raiders have conquered your colony! Your people are now their slaves. Plan your uprising!", MessageTypeDefOf.ThreatBig, validateFaction: false);

            return false; // Skip vanilla game over
        }

        private static void DoTakeover(Map map)
        {
            // Healthy hostile humanlikes = new colonists
            List<Pawn> newColonists = map.mapPawns.AllPawnsSpawned
                .Where(p => !p.Dead && !p.Downed && p.RaceProps.Humanlike
                         && p.Faction.HostileTo(Faction.OfPlayer) && !p.IsQuestLodger())
                .ToList();

            if (!newColonists.Any()) return; // No survivors = true defeat

            Pawn master = newColonists.RandomElement();

            // End raid lords
            foreach (Lord lord in map.lordManager.lords.Where(l => l.LordJob is LordJob_AssaultColony).ToList())
            {
                lord.EndLordJob();
            }

            // Recruit new colonists
            foreach (Pawn pawn in newColonists)
            {
                pawn.SetFaction(Faction.OfPlayer);
            }

            // Execute downed raiders (brutal!)
            foreach (Pawn pawn in map.mapPawns.AllPawnsSpawned
                .Where(p => p.Downed && p.RaceProps.Humanlike && p.Faction.HostileTo(Faction.OfPlayer)).ToList())
            {
                pawn.Kill(new DamageInfo(DamageDefOf.Cut, 999f));
            }

            // Enslave original downed colonists
            foreach (Pawn pawn in map.mapPawns.AllPawnsSpawned
                .Where(p => p.Faction == Faction.OfPlayer && p.Downed && p.RaceProps.Humanlike).ToList())
            {
                pawn.SetFaction(null);
                pawn.slaveTracker?.SetSlave(true, master);
            }
        }
    }
}